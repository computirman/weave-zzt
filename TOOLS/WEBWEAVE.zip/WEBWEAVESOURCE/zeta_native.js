var ZetaNative = (() => {
  var _scriptName = typeof document != 'undefined' ? document.currentScript?.src : undefined;
  return (
async function(moduleArg = {}) {
  var moduleRtn;

var b=moduleArg,c,n,p=new Promise((a,d)=>{c=a;n=d}),q="",t;try{q=(new URL(".",_scriptName)).href}catch{}t=async a=>{a=await fetch(a,{credentials:"same-origin"});if(a.ok)return a.arrayBuffer();throw Error(a.status+" : "+a.url);};var u=console.log.bind(console),v=console.error.bind(console),x,C=!1,D,E;
function F(){var a=x.buffer;new Int8Array(a);new Int16Array(a);b.HEAPU8=D=new Uint8Array(a);new Uint16Array(a);new Int32Array(a);b.HEAPU32=E=new Uint32Array(a);new Float32Array(a);new Float64Array(a);new BigInt64Array(a);new BigUint64Array(a)}var G=0,H=null,I;async function J(a){try{var d=await t(a);return new Uint8Array(d)}catch{}throw"both async and sync fetching of the wasm failed";}
async function K(a,d){try{var e=await J(a);return await WebAssembly.instantiate(e,d)}catch(h){throw v(`failed to asynchronously prepare wasm: ${h}`),a=h,a="Aborted("+a+")",v(a),C=!0,a=new WebAssembly.RuntimeError(a+". Build with -sASSERTIONS for more info."),n(a),a;}}
async function N(a){var d=I;if("function"==typeof WebAssembly.instantiateStreaming)try{var e=fetch(d,{credentials:"same-origin"});return await WebAssembly.instantiateStreaming(e,a)}catch(h){v(`wasm streaming compile failed: ${h}`),v("falling back to ArrayBuffer instantiation")}return K(d,a)}var O=[null,[],[]],P="undefined"!=typeof TextDecoder?new TextDecoder:void 0,Q=a=>{for(var d="";;){var e=D[a++];if(!e)return d;d+=String.fromCharCode(e)}};b.AsciiToString=Q;
var R={d:function(a){console.log(Q(a))},m:a=>{var d=D.length;a>>>=0;if(2147483648<a)return!1;for(var e=1;4>=e;e*=2){var h=d*(1+.2/e);h=Math.min(h,a+100663296);a:{h=(Math.min(2147483648,65536*Math.ceil(Math.max(a,h)/65536))-x.buffer.byteLength+65535)/65536|0;try{x.grow(h);F();var r=1;break a}catch(y){}r=void 0}if(r)return!0}return!1},o:()=>52,n:function(){return 70},i:(a,d,e,h)=>{for(var r=0,y=0;y<e;y++){var T=E[d>>2],L=E[d+4>>2];d+=8;for(var z=0;z<L;z++){var w=a,f=D[T+z],A=O[w];if(0===f||10===f){w=
1===w?u:v;f=A;for(var k=0,l=k+NaN,m=k;f[m]&&!(m>=l);)++m;if(16<m-k&&f.buffer&&P)f=P.decode(f.subarray(k,m));else{for(l="";k<m;){var g=f[k++];if(g&128){var B=f[k++]&63;if(192==(g&224))l+=String.fromCharCode((g&31)<<6|B);else{var M=f[k++]&63;g=224==(g&240)?(g&15)<<12|B<<6|M:(g&7)<<18|B<<12|M<<6|f[k++]&63;65536>g?l+=String.fromCharCode(g):(g-=65536,l+=String.fromCharCode(55296|g>>10,56320|g&1023))}}else l+=String.fromCharCode(g)}f=l}w(f);A.length=0}else A.push(f)}r+=L}E[h>>2]=r;return 0},g:function(a){speakerg_off(a)},
l:function(a,d){speakerg_on(a,d)},u:function(a){return vfsg_chdir(a)},v:function(a){return vfsg_close(a)},q:function(a,d,e){return vfsg_findfirst(a,d,e)},p:function(a){return vfsg_findnext(a)},t:function(a,d){return vfsg_getcwd(a,d)},j:function(a,d){return vfsg_open(a,d)},a:function(a,d,e){return vfsg_read(a,d,e)},c:function(a,d,e){return vfsg_seek(a,d,e)},s:function(a,d){return vfsg_truncate(a,d)},r:function(a,d,e){return vfsg_write(a,d,e)},h:function(a){return vfsg_has_feature(a)},k:function(){return vfsg_time_ms()},
b:function(a){return zetag_update_blink(a)},e:function(a,d,e){return zetag_update_charset(a,d,e)},f:function(a){return zetag_update_palette(a)}},S=await (async function(){G++;var a={a:R};I??=q+"zeta_native.wasm";try{return S=(await N(a)).instance.exports,x=S.w,F(),G--,0==G&&H&&(a=H,H=null,a()),S}catch(d){return n(d),Promise.reject(d)}}());b._zzt_get_ip=S.y;b._zzt_get_cycles=S.z;b._zzt_kmod_get=S.A;b._zzt_kmod_set=S.B;b._zzt_kmod_clear=S.C;b._zzt_set_lock_charset=S.D;
b._zzt_set_lock_palette=S.E;b._zzt_key_get_delay=S.F;b._zzt_key_get_repeat_delay=S.G;b._zzt_key_set_delay=S.H;b._zzt_key=S.I;b._zzt_keyup=S.J;b._zzt_mark_frame=S.K;b._zzt_joy_set=S.L;b._zzt_joy_clear=S.M;b._zzt_joy_axis=S.N;b._zzt_mouse_set=S.O;b._zzt_mouse_clear=S.P;b._zzt_mouse_axis=S.Q;b._zzt_get_charset_default=S.R;b._zzt_force_default_charset=S.S;b._zzt_load_charset=S.T;b._zzt_set_timer_offset=S.U;b._zzt_set_max_extended_memory=S.V;b._zzt_video_mode=S.W;b._zzt_load_palette_default=S.X;
b._zzt_key_pop=S.Y;b._zzt_load_binary=S.Z;b._zzt_load_ega_palette=S._;b._zzt_load_palette=S.$;b._zzt_load_blink=S.aa;b._zzt_get_active_blink_duration_ms=S.ba;b._zzt_get_screen_size=S.ca;b._zzt_get_charset=S.da;b._zzt_get_palette=S.ea;b._zzt_get_blink=S.fa;b._zzt_get_blink_user_override=S.ga;b._zzt_set_blink_user_override=S.ha;b._zzt_get_blink_duration_ms=S.ia;b._zzt_set_blink_duration_ms=S.ja;b._zzt_init=S.ka;b._audio_set_remove_player_movement_sound=S.la;b._zzt_execute=S.ma;
b._zzt_get_pit_tick_ms=S.na;b._zzt_mark_timer=S.oa;b._zzt_mark_timer_turbo=S.pa;b._zzt_get_ram=S.qa;b._malloc=S.ra;b._free=S.sa;b._ui_activate=S.ta;b._audio_stream_get_volume=S.ua;b._audio_get_remove_player_movement_sound=S.va;b._audio_stream_set_volume=S.wa;b._audio_stream_init=S.xa;b._audio_stream_get_max_volume=S.ya;b._audio_stream_generate=S.za;b._audio_stream_append_on=S.Aa;b._audio_local_delay_time=S.Ba;b._audio_should_insert_pause=S.Ca;b._audio_stream_append_off=S.Da;
b._audio_generate_init=S.Ea;b._audio_get_note_delay=S.Fa;b._audio_set_note_delay=S.Ga;function U(){0<G?H=U:0<G?H=U:(b.calledRun=!0,C||(S.x(),c(b)))}U();moduleRtn=p;


  return moduleRtn;
}
);
})();
if (typeof exports === 'object' && typeof module === 'object') {
  module.exports = ZetaNative;
  // This default export looks redundant, but it allows TS to import this
  // commonjs style module.
  module.exports.default = ZetaNative;
} else if (typeof define === 'function' && define['amd'])
  define([], () => ZetaNative);
